## CodingBat - Python

| Section                                           |          Solved/Total         |   | Section                                           |          Solved/Total         |
|---------------------------------------------------|:-----------------------------:|---|---------------------------------------------------|:-----------------------------:|
| [Warmup-1](https://codingbat.com/python/Warmup-1) | [12/12](solutions/warmup1.py) |   | [String-1](https://codingbat.com/python/String-1) | [11/11](solutions/string1.py) |
| [Warmup-2](https://codingbat.com/python/Warmup-2) |  [9/9](solutions/warmup2.py)  |   | [String-2](https://codingbat.com/python/String-2) |  [6/6](solutions/string2.py)  |
| [Logic-1](https://codingbat.com/python/Logic-1)   |   [9/9](solutions/logic1.py)  |   | [List-1](https://codingbat.com/python/List-1)     |  [12/12](solutions/list1.py)  |
| [Logic-2](https://codingbat.com/python/Logic-2)   |   [7/7](solutions/logic2.py)  |   | [List-2](https://codingbat.com/python/List-2)     |   [6/6](solutions/list2.py)   |

_(For Java solutions, see [here](../java))_
