"""
Topics: | None |
"""

UPDATE salary
   SET sex = IF(sex = 'm', 'f', 'm')
