expression = input()
eval(expression)
