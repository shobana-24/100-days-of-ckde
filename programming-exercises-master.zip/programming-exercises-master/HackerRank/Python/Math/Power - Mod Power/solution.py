a, b, m = (int(input()) for _ in range(3))
print(pow(a, b))
print(pow(a, b, m))
