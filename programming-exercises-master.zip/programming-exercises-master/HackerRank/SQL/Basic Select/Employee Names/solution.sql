SELECT Name
  FROM Employee
 ORDER BY Name;
