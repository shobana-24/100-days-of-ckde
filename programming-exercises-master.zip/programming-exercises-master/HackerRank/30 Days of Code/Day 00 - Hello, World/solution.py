input_string = input()
print('Hello, World.')
print(input_string)
