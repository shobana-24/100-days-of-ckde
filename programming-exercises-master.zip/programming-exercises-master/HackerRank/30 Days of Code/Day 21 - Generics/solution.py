"""
Challenge not enabled for Python.
"""